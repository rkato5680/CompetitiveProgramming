# problem: https://atcoder.jp/contests/abc103/tasks/abc103_c
# code: https://atcoder.jp/contests/abc103/submissions/15572604

N=int(input())
a=list(map(int,input().split()))

print(sum(a) - N)